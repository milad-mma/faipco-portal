"""Adapter اتصال به دیتابیس منبع از نوع PostgreSQL (با psycopg2، به‌صورت Thread-safe در Executor)."""
import asyncio

import psycopg2
import psycopg2.extras

from app.sync_engine.adapters.base import BaseSiteAdapter


class PostgreSQLAdapter(BaseSiteAdapter):
    def _connect(self):
        return psycopg2.connect(
            host=self.host,
            port=self.port,
            dbname=self.database,
            user=self.username,
            password=self.password,
            connect_timeout=10,
        )

    async def test_connection(self) -> tuple[bool, str | None]:
        return await asyncio.to_thread(self._test_connection_sync)

    def _test_connection_sync(self) -> tuple[bool, str | None]:
        try:
            conn = self._connect()
            conn.close()
            return True, None
        except Exception as e:  # noqa: BLE001 - خطای واقعی درایور باید به کاربر نمایش داده شود
            return False, str(e)

    async def fetch_rows(self, table_name: str, columns: list[str]) -> list[dict]:
        return await asyncio.to_thread(self._fetch_rows_sync, table_name, columns)

    def _fetch_rows_sync(self, table_name: str, columns: list[str]) -> list[dict]:
        conn = self._connect()
        try:
            cols_sql = ", ".join(f'"{c}"' for c in columns)
            query = f'SELECT {cols_sql} FROM "{table_name}"'  # noqa: S608 - نام جدول/ستون از Mapping مدیریتی می‌آید نه ورودی کاربر نهایی
            with conn.cursor(cursor_factory=psycopg2.extras.RealDictCursor) as cur:
                cur.execute(query)
                return [dict(row) for row in cur.fetchall()]
        finally:
            conn.close()
