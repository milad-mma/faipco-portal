"""
روتر مرکزی نسخه v1 از API.
"""
from fastapi import APIRouter

from app.api.v1.endpoints import auth, departments, employees, notices, push, sites, sync, users

api_router = APIRouter()

api_router.include_router(auth.router, prefix="/auth", tags=["auth"])
api_router.include_router(employees.router, prefix="/employees", tags=["employees"])
api_router.include_router(sites.router, prefix="/sites", tags=["sites"])
api_router.include_router(departments.router, prefix="/departments", tags=["departments"])
api_router.include_router(sync.router, prefix="/sync", tags=["sync"])
api_router.include_router(notices.router, prefix="/notices", tags=["notices"])
api_router.include_router(users.router, prefix="/users", tags=["users"])
api_router.include_router(push.router, prefix="/push", tags=["push"])
