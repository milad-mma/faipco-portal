# نصب روی سرور Production


روی یک Ubuntu Server (22.04 یا 24.04)، با دسترسی root:

```bash
curl -fsSL https://raw.githubusercontent.com/milad-mma/faipco-portal/main/install.sh | sudo bash
```

یا با آرگومان‌های دلخواه:

```bash
curl -fsSL https://raw.githubusercontent.com/milad-mma/faipco-portal/main/install.sh -o install.sh
sudo bash install.sh --domain portal.mycompany.com --admin-username admin
```

اسکریپت به‌صورت خودکار **نصب یا آپدیت** را تشخیص می‌دهد (بر اساس اینکه
`backend/.env` از قبل وجود دارد یا نه):

- **نصب تازه**: پیش‌نیازها (Python، Node.js، PostgreSQL، Nginx) → ساخت
  دیتابیس با پسورد تصادفی امن → Clone سورس → نصب وابستگی‌ها → تولید `.env` با
  کلیدهای امنیتی یکتا + کلیدهای VAPID → Migration ها → Build فرانت‌اند → سرویس
  systemd (`faipco-backend`) → پیکربندی Nginx → Seed اولیه + ساخت کاربر Admin
  → تنظیم فایروال (UFW).
- **آپدیت** (وقتی نصب قبلی پیدا شود): `.env`، پسورد دیتابیس، کلیدهای VAPID و
  خودِ دیتابیس **هرگز دست‌خورده نمی‌شوند** — فقط سورس رفرش، وابستگی‌ها دوباره
  نصب، Migration های جدید به‌صورت افزایشی اجرا (`alembic upgrade head`،
  هیچ‌وقت داده‌ای پاک نمی‌کند)، فرانت‌اند دوباره Build، و سرویس‌ها Restart
  می‌شوند. یعنی هر بار که روی GitHub Push می‌کنید، همین یک دستور برای Deploy
  کافی است.

**آرگومان‌های قابل استفاده:**

| آرگومان | توضیح | پیش‌فرض |
|---|---|---|
| `--domain` | دامنه پرتال (فقط برای CORS استفاده می‌شود) | ندارد (فقط IP سرور) |
| `--admin-username` | نام کاربری Admin اولیه (فقط نصب تازه) | `admin` |
| `--admin-password` | رمز عبور Admin اولیه (فقط نصب تازه) | `admin` |
| `--install-dir` | مسیر نصب روی سرور | `/var/www/html` |
| `--repo` | آدرس Git Repository | `github.com/milad-mma/faipco-portal` |
| `--branch` | Branch مورد استفاده | `main` |

⚠️ اگر `--admin-password` ندهید، پسورد پیش‌فرض `admin` است — حتماً بلافاصله
بعد از اولین ورود عوض کنید.

**نکته مهم درباره SSL**: این اسکریپت دیگر خودش SSL/Let's Encrypt را مدیریت
نمی‌کند — Nginx محلی همیشه روی HTTP ساده (پورت ۸۰) اجرا می‌شود و SSL باید توسط
یک Reverse Proxy خارجی (که از قبل روی سرور یا جلوی آن راه‌اندازی شده) تأمین
شود. آرگومان `--domain` فقط برای تنظیم صحیح CORS استفاده می‌شود.

نصب با Docker از پروژه حذف شده است؛ تنها روش پشتیبانی‌شده همین `install.sh` است.
