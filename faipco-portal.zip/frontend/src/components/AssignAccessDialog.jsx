import { useEffect, useState } from "react";
import {
  Alert,
  Button,
  Checkbox,
  Chip,
  Dialog,
  DialogActions,
  DialogContent,
  DialogTitle,
  Divider,
  FormControlLabel,
  MenuItem,
  Stack,
  TextField,
  Typography,
} from "@mui/material";
import DeleteOutlineIcon from "@mui/icons-material/DeleteOutline";
import { assignRoleToEmployee, fetchEmployeeRoles, fetchSupervisedDepartments } from "../api/employees";
import { fetchRoles, removeRoleAssignment } from "../api/users";
import { assignDepartmentSupervisor, fetchDepartments } from "../api/departments";

export default function AssignAccessDialog({ employee, sites, onClose }) {
  const [roles, setRoles] = useState([]);
  const [employeeRoles, setEmployeeRoles] = useState([]);
  const [allDepartments, setAllDepartments] = useState([]);
  const [supervisedDeptIds, setSupervisedDeptIds] = useState([]);

  const [roleToAssign, setRoleToAssign] = useState("");
  const [siteForRole, setSiteForRole] = useState("");

  const [error, setError] = useState("");
  const [success, setSuccess] = useState("");

  useEffect(() => {
    if (!employee) return;
    setError("");
    setSuccess("");
    fetchRoles().then(setRoles);
    fetchEmployeeRoles(employee.id).then(setEmployeeRoles);
    fetchDepartments().then(setAllDepartments);
    fetchSupervisedDepartments(employee.id).then(setSupervisedDeptIds);
  }, [employee]);

  if (!employee) return null;

  const siteLabel = (id) => sites.find((s) => s.id === id)?.name || "—";
  const roleLabel = (id) => roles.find((r) => r.id === id)?.name || id;
  const selectedRoleIsSiteScoped = roles.find((r) => r.id === roleToAssign)?.name === "site_manager";

  async function handleAssignRole() {
    setError("");
    setSuccess("");
    try {
      await assignRoleToEmployee(employee.id, roleToAssign, siteForRole || null);
      setEmployeeRoles(await fetchEmployeeRoles(employee.id));
      setRoleToAssign("");
      setSiteForRole("");
      setSuccess("نقش با موفقیت اختصاص یافت.");
    } catch (err) {
      setError(err.response?.data?.detail || "انتصاب نقش ناموفق بود");
    }
  }

  async function handleRemoveRole(userRoleId) {
    await removeRoleAssignment(userRoleId);
    setEmployeeRoles(await fetchEmployeeRoles(employee.id));
  }

  async function handleToggleDepartment(departmentId, isChecked) {
    setError("");
    try {
      await assignDepartmentSupervisor(departmentId, isChecked ? employee.id : null);
      setSupervisedDeptIds(await fetchSupervisedDepartments(employee.id));
    } catch (err) {
      setError(err.response?.data?.detail || "به‌روزرسانی سرپرستی ناموفق بود");
    }
  }

  return (
    <Dialog open={Boolean(employee)} onClose={onClose} fullWidth maxWidth="xs">
      <DialogTitle>
        دسترسی — {employee.first_name} {employee.last_name}
        <Typography variant="caption" color="text.secondary" display="block">
          کد پرسنلی: {employee.personnel_code} · سایت: {siteLabel(employee.site_id)}
        </Typography>
      </DialogTitle>
      <DialogContent sx={{ display: "flex", flexDirection: "column", gap: 2, pt: 1 }}>
        {error && <Alert severity="error">{error}</Alert>}
        {success && <Alert severity="success">{success}</Alert>}

        {/* نقش‌های سازمانی فعلی */}
        <Stack spacing={1}>
          <Typography variant="subtitle2" fontWeight={700}>
            نقش سازمانی
          </Typography>
          {employeeRoles.length === 0 && (
            <Typography variant="body2" color="text.secondary">
              هنوز نقشی اختصاص نیافته.
            </Typography>
          )}
          {employeeRoles.map((ur) => (
            <Stack
              key={ur.id}
              direction="row"
              alignItems="center"
              justifyContent="space-between"
              sx={{ p: 1, border: "1px solid", borderColor: "divider", borderRadius: 2 }}
            >
              <Chip
                size="small"
                label={`${roleLabel(ur.role_id)}${ur.site_id ? ` — ${siteLabel(ur.site_id)}` : " (سراسری)"}`}
              />
              <Button size="small" color="error" onClick={() => handleRemoveRole(ur.id)}>
                <DeleteOutlineIcon fontSize="small" />
              </Button>
            </Stack>
          ))}
        </Stack>

        <TextField
          select
          size="small"
          label="اختصاص نقش جدید"
          value={roleToAssign}
          onChange={(e) => {
            setRoleToAssign(e.target.value);
            setSiteForRole("");
          }}
        >
          {roles.map((r) => (
            <MenuItem key={r.id} value={r.id}>
              {r.name === "site_manager" ? "مدیر سایت" : r.name === "middle_manager" ? "مدیر میانی" : r.name}
            </MenuItem>
          ))}
        </TextField>

        {selectedRoleIsSiteScoped && (
          <TextField
            select
            size="small"
            label="این نقش برای کدام سایت است؟"
            value={siteForRole}
            onChange={(e) => setSiteForRole(e.target.value)}
          >
            {sites.map((s) => (
              <MenuItem key={s.id} value={s.id}>
                {s.name}
              </MenuItem>
            ))}
          </TextField>
        )}

        <Button
          variant="outlined"
          size="small"
          disabled={!roleToAssign || (selectedRoleIsSiteScoped && !siteForRole)}
          onClick={handleAssignRole}
        >
          اختصاص این نقش
        </Button>

        <Divider />

        {/* سرپرستی واحد(ها) — یک نفر می‌تواند سرپرست چند واحد باشد */}
        <Typography variant="subtitle2" fontWeight={700}>
          سرپرست کدام واحدهاست؟
        </Typography>
        <Typography variant="caption" color="text.secondary">
          می‌توانید همین شخص را هم‌زمان سرپرست چند واحد سازمانی کنید.
        </Typography>
        <Stack spacing={0.5} sx={{ maxHeight: 220, overflowY: "auto" }}>
          {allDepartments.length === 0 && (
            <Typography variant="body2" color="text.secondary">
              هنوز هیچ واحد سازمانی‌ای وجود ندارد.
            </Typography>
          )}
          {allDepartments.map((dept) => (
            <FormControlLabel
              key={dept.id}
              control={
                <Checkbox
                  size="small"
                  checked={supervisedDeptIds.includes(dept.id)}
                  onChange={(e) => handleToggleDepartment(dept.id, e.target.checked)}
                />
              }
              label={`${dept.name} — ${siteLabel(dept.site_id)}`}
            />
          ))}
        </Stack>
      </DialogContent>
      <DialogActions sx={{ p: 2.5 }}>
        <Button onClick={onClose}>بستن</Button>
      </DialogActions>
    </Dialog>
  );
}
